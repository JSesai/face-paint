const errorHandler = (error) => {
  console.error("Error en la Lambda:", error);

  const statusCode = error.isOperational ? error.statusCode : 500;
  const message = error.isOperational ? error.message : "Error interno del servidor";

  return { statusCode, message, errorDetail: error };

};

export default errorHandler;