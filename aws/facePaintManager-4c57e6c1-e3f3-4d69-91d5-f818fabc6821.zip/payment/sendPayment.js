import axios from 'axios';
import { randomUUID } from 'crypto';
import { MercadoPagoConfig, Payment } from 'mercadopago';
import { createReservation } from '../reservation/use-case-reservation.js';

export const sendPayment = async (infoPayment) => {
    try {

        const info = JSON.parse(infoPayment);
        
        const { token, issuer_id, installments, payment_method_id, transaction_amount, payer, ...infEvent } = info;
        const accessToken = process.env.TOKEN_MERCADO_PAGO
        if (!accessToken) throw new Error('no hay token de mercado pago')
        const idempotencyKey = randomUUID();

        // Step 2: Initialize the client object
        const client = new MercadoPagoConfig({ accessToken, options: { timeout: 5000, idempotencyKey } });

        // Step 3: Initialize the API object
        const payment = new Payment(client);

        // Step 4: Create the request object
        const body = {
            token,
            issuer_id,
            transaction_amount,
            installments,
            description: 'servicion FP',
            payment_method_id,
            payer,
        };

        // Step 5: Create request options object - Optional
        const requestOptions = { idempotencyKey, };

        // Step 6: Make the request
        const response = await payment.create({ body, requestOptions })
       
        const dataReservacion = {
            ...infEvent,
            id: idempotencyKey,
            name: response.card.cardholder.name,
            statusPayment: response.status,
            paidAmountReservation: response.transaction_amount,
            paymetRegister: JSON.stringify(response)
        }

        await createReservation(dataReservacion)
        return { statuscode: 200, response: { status:response.status, status_detail: response.status_detail } }

    } catch (error) {
        console.log(error);
        return { statuscode: 500, message: 'error al crear preferencias de pago', error }

    }
}
