import { randomUUID } from 'crypto';
import { sendPayment } from "./sendPayment.js"



export const handlerPayment = async (event) => {
    const { httpMethod, path, body, pathParameters } = event
  
    let res;

    console.log('path->', path);

    switch (path) {
        case ('/payment'):
            if (httpMethod === 'POST') res = await sendPayment(body)
            return res
            break;

            
        default:
            throw new Error('No se encuentra el path del end point invocado')
    }
}