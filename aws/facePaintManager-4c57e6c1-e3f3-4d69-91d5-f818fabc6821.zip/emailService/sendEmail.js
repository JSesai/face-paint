import AWS from 'aws-sdk';

const dynamoDB = new AWS.DynamoDB.DocumentClient({ region: 'us-east-1', });
const ses = new AWS.SES({ region: 'us-east-1' });


//envio de email, recibe un arreglo de emails como destinatario, asunto y el mensaje en html a enviar
export const sendEmail = async ({ addressees, subject, message }) => {
    if (!addressees || !subject || !message) throw new Error(`Faltan datos para enviar correo ${{ addressees, subject, message }}`)

    const params = {
        Source: 'antonio.sesai@gmail.com',
        Destination: { ToAddresses: addressees },
        Message: {
            Subject: { Data: subject },
            Body: {
                Html: {
                    Data: message,
                    Charset: 'UTF-8',
                },
            },
        },
    };

    try {
        const resultado = await ses.sendEmail(params).promise();
        console.log('Correo enviado:', resultado);
        return resultado
    } catch (error) {
        console.error('Error al enviar el correo de registro:', error);
        throw error;
    }
};
