import { sendEmail } from "./sendEmail.js"


export const sendEmailReservation = async (reservacion) => {

  try {
    if (!reservacion) {
      throw new Error(`Faltan datos para enviar el correo. ${reservacion}`);
    }
    const {
      name,
      eventType,
      eventDate,
      eventTime,
      contactNumber,
      numeroReferencia,
      estatusEvent,
      selectedPackage,
      ubicatioEvent,
      id
    } = reservacion;
    // const email = 'tazagut@gmail.com';
    const email = 'bonsai_87@hotmail.com';
    const managers = 'Talia';
    const template = `
    <h2>Hola, ${managers}</h2>
    <p>Se ha registrado una nueva <strong>reservación</strong></p>
    <ul>
      <li>Nombre: ${name}</li>
      <li>Tipo de Evento: ${eventType}</li>
      <li>Fecha: ${eventDate}</li>
      <li>Hora: ${eventTime}</li>
      <li>Número de Contacto: ${contactNumber}</li>
      <li>Paquete: ${selectedPackage.title} precio: $${selectedPackage.price}</li>
      <li>Ubicación del evento: <a href="https://www.google.com/maps?q=${ubicatioEvent.lat},${ubicatioEvent.lon}" target="_blank">
      Ver ubicación en Google Maps
    </a>
    </li>
    </ul>
    <p>Por favor, revisa la información y confirma la reservación del evento.</p>
    <br>
   
    <table cellspacing="0" cellpadding="0" border="0" align="center">
      <tr>
        <td align="center" style="border-radius: 5px;" bgcolor="#007BFF">
          <a href="${process.env.FRONTEND_URL}/events/confirmar-reservacion/${id}" 
            target="_blank" 
            style="display: inline-block; font-family: Arial, sans-serif; font-size: 16px; color: #ffffff; text-decoration: none; padding: 12px 24px; border-radius: 5px; background-color: #007BFF;">
            Confirmar Reservación
          </a>
        </td>
      </tr>
    </table>
  `;

    const infoEmail = {
      addressees: [email],
      subject: "FacePaint MAJO - Nueva Reservación",
      message: template
    }

    const sendEmailRegister = await sendEmail(infoEmail)
    return sendEmailRegister
  } catch (error) {
    console.log(error);
    throw error
  }
}
export const sendEmailAquote = async (reservacion) => {

  try {
    if (!reservacion) {
      throw new Error(`Faltan datos para enviar el correo. ${reservacion}`);
    }
    const {
      name,
      eventType,
      eventDate,
      eventTime,
      contactNumber,
      ubicatioEvent,
      id
    } = reservacion;
    // const email = 'tazagut@gmail.com';
    const email = 'bonsai_87@hotmail.com';
    const managers = 'Talia';
    const template = `
    <h2>Hola, ${managers}</h2>
    <p>Se ha registrado una nueva <strong>cotización</strong></p>
    <ul>
      <li>Nombre: ${name}</li>
      <li>Tipo de Evento: ${eventType}</li>
      <li>Fecha: ${eventDate}</li>
      <li>Hora: ${eventTime}</li>
      <li>Número de Contacto: ${contactNumber}</li>
      <li>Ubicación del evento: <a href="https://www.google.com/maps?q=${ubicatioEvent.lat},${ubicatioEvent.lon}" target="_blank">
      Ver ubicación en Google Maps
    </a>
    </li>
    </ul>
    <p>Por favor, revisa la información y confirma la Cotización del evento.</p>
    <br>
   
    <table cellspacing="0" cellpadding="0" border="0" align="center">
      <tr>
        <td align="center" style="border-radius: 5px;" bgcolor="#007BFF">
          <a href="${process.env.FRONTEND_URL}/events/enviar-cotizacion/${id}" 
            target="_blank" 
            style="display: inline-block; font-family: Arial, sans-serif; font-size: 16px; color: #ffffff; text-decoration: none; padding: 12px 24px; border-radius: 5px; background-color: #9e27e3;">
            Enviar Cotización
          </a>
        </td>
      </tr>
    </table>
  `;

    const infoEmail = {
      addressees: [email],
      subject: "FacePaint MAJO - Nueva Cotización",
      message: template
    }

    const sendEmailRegister = await sendEmail(infoEmail)
    return sendEmailRegister
  } catch (error) {
    console.log(error);
    throw error
  }
}

export const sendEmailRegister = async ({ email, nombre, token }) => {

  try {
    if (!email || !nombre || !token) {
      throw new Error(`Faltan datos para enviar el correo. ${email, nombre, token}`);
    }
    const template = `
    <h2>Hola, ${nombre}</h2>
    <p>Gracias por registrarte. Por favor, confirma tu cuenta haciendo clic en el siguiente enlace:</p>
    <a href="${process.env.FRONTEND_URL}/confirm-account/${token}">Confirmar cuenta</a>
    <p>Si no te registraste, ignora este mensaje.</p>     `;

    const infoEmail = {
      addressees: [email],
      subject: "FacePaint MAJO - Comprueba La Reservación ",
      message: template
    }

    const sendEmailRegister = await sendEmail(infoEmail)
    return sendEmailRegister
  } catch (error) {
    console.log(error);
    throw error
  }
}

export const sendEmailRecoverPassword = async ({ email, nombre, token }) => {

  try {
    if (!email || !nombre || !token) {
      throw new Error(`Faltan datos para enviar el correo. ${email, nombre, token}`);
    }
    const template = `
    <h2>Hola, ${nombre}</h2>
    <p>Estamos recuperando tu cuenta. Por favor continua el proceso haciendo clic en el siguiente enlace:</p>
    <a href="${process.env.FRONTEND_URL}/olvide-password/${token}">Recuperar cuenta</a>
    <p>Si no recuperaste tu cuenta, ignora este mensaje.</p>  
    `;

    const infoEmail = {
      addressees: [email],
      subject: "FacePaint MAJO - Recupera tu Contraseña",
      message: template
    }

    const sendEmailRegister = await sendEmail(infoEmail)
    return sendEmailRegister
  } catch (error) {
    console.log(error);
    throw error
  }
}
