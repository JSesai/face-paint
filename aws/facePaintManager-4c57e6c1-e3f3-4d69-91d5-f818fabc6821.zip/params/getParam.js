import { getObjectById } from "../dynamoDBService/dynamoService.js"

//Identificador de proyecto 
const identifier = process.env.IDENTIFIER
identifier ?? console.error('no hay identificador de proyecto');

//obtiene el parametro de informacion
export const getParam = async (body) => {
    
    try {

        let { id } = JSON.parse(body);
        const paramFacePaint = await getObjectById(`param-facePaint-${identifier}`, id);
        return { statuscode: 200, paramFacePaint };

    } catch (error) {
        console.log('error al obtener el parametro de facePaint', error);
        return { statuscode: 400, message: error.message };
    }
}