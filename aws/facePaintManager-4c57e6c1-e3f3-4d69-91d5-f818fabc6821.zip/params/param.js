import { getParam } from './getParam.js'


export const handlerParams = async (event) => {
    const { httpMethod, path, body, pathParameters } = event
  
    let res;

    //console.log('path->', path);

    switch (path) {
        
        case ('/param'):
            if (httpMethod === 'POST') res = await getParam(body)
            return res
            break

        default:
            throw new Error('No se encuentra el path del end point invocado')
    }
}