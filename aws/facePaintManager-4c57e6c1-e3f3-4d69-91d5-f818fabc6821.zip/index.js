import AppError from './appError/AppError.js';
import errorHandler from './appError/errorHandler.js';
import { handlerUser } from "./users/handlerUser.js"
import { handlerReservation } from "./reservation/index.js"
import { handlerParams } from "./params/param.js"
import { handlerPayment } from "./payment/payment.js"


export const handler = async (event) => {
  console.log('handlerApi');
  const { path } = event;
  //macheo de ruta
  const pathMatch = path.split('/')[1];
  console.log(pathMatch);
  let res;
  try {

    switch (pathMatch) {
      case ('param'):
        res = await handlerParams(event)
        break;

      case ('reservation'):
        res = await handlerReservation(event)
        break;

      case ('payment'):
        res = await handlerPayment(event)
        break;


      case ('users'):
        res = await handlerUser(event)
        break


      default:
        throw new AppError('No method found in the handler :(', 400)
      // res = { statuscode: 400, message: 'No method found in the handler :(' }

    }

    if (!res) throw new AppError('error en el manejo de la respuesta', 400)

    return {
      statusCode: res.statuscode,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Credentials": true,
      },
      body: JSON.stringify(res),
    }

  } catch (error) {
    console.log('errrror', error);
    const err = errorHandler(error);
    const { statusCode, message, errorDetail } = err;
    const respErr = {
      statusCode: statusCode || 500,
      body: JSON.stringify({ message: message ? message : 'error en el server', errorDetail: errorDetail ? errorDetail : "Error interno" }),
    };
    console.log('este es el error que se retornara: ', respErr);
    return respErr
  }

}


