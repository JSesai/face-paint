import AWS from 'aws-sdk';
import { randomUUID } from 'crypto';


const dynamoDB = new AWS.DynamoDB.DocumentClient({ region: 'us-east-1', });
const ses = new AWS.SES({ region: 'us-east-1' });

//obtiene un objeto por valor de propiedad, recibe la tabla, la propiedad a filtrar  y el valor a filtrar
export const getObjectDynamo = async (table, propFilter, valueFilter) => {

    try {
        if (!table || !propFilter || !valueFilter) {
            console.log('faltan datos para hacer la busqueda, debes de proporcionar la tabla, la propiedad y el valor de la propiedad');
            throw new Error("Error en la consulta");
        }
        const params = {
            TableName: table,
            FilterExpression: `${propFilter} = :value`,
            ExpressionAttributeValues: {
                ':value': valueFilter
            }
        };

        const result = await dynamoDB.scan(params).promise();
        return result

    } catch (error) {
        console.log(error);
        throw error;
    }
}

//obtiene registro por id, recibe tabla y id del item
export const getObjectById = async (table, id) => {
    try {
        if (!table || !id) throw new Error(`proporciona los datos de tabla: ${ table } y id: ${ id }`)
        const params = {
            TableName: table,
            Key: { id }
        }
        const result = await dynamoDB.get(params).promise();
        return result.Item || null;
    } catch (error) {
        console.log(error);
        throw error
    }
}

//inserta un objeto, recibe la tabla, y el valor a insertar
export const insertObjectDynamo = async (table, item) => {

    try {
        if (!table || !item) throw new Error("Faltan datos para realizar la inserción");
        console.log('item', item);
        try {
            const params = {
                TableName: table,
                Item: item,
            };
            const result = await dynamoDB.put(params).promise();
            return result
        } catch (error) {
            console.error('Error al insertar en DynamoDB:', error);
            throw new Error('Error al insertar en DynamoDB');
        }

    } catch (error) {
        console.log(error);
        throw error;
    }
}

//actualiza un objeto, recibe la tabla, el id y el objeto con los valores a actualizar
export const updateObject = async (table, id, updates) => {

    try {
        if (!table || !id || !updates) throw new Error("Faltan datos para realizar la actualizacion");

        const UpdateExpression = 'set ' + Object.keys(updates).map((key, idx) => `#${key} = :val${idx}`).join(', ');
        const ExpressionAttributeNames = Object.keys(updates).reduce((acc, key) => ({ ...acc, [`#${key}`]: key }), {});
        const ExpressionAttributeValues = Object.values(updates).reduce((acc, val, idx) => ({ ...acc, [`:val${idx}`]: val }), {});

        const params = {
            TableName: table,
            Key: { id },
            UpdateExpression,
            ExpressionAttributeNames,
            ExpressionAttributeValues,
            ReturnValues: 'UPDATED_NEW'
        };

        const result = await dynamoDB.update(params).promise();
        return result.Attributes;

    } catch (error) {
        console.log(error);
        throw error;
    }
}

//envio de email, recibe un arreglo de emails como destinatario, asunto y el mensaje en html a enviar
export const sendEmail = async ({ addressees, subject, message }) => {
    if (!addressees || !subject || !message) throw new Error(`Faltan datos para enviar correo ${{ addressees, subject, message }}`)

    const params = {
        Source: 'antonio.sesai@gmail.com',
        Destination: { ToAddresses: addressees },
        Message: {
            Subject: { Data: subject },
            Body: {
                Html: {
                    Data: message,
                    Charset: 'UTF-8',
                },
            },
        },
    };

    try {
        const resultado = await ses.sendEmail(params).promise();
        console.log('Correo enviado:', resultado);
        return resultado
    } catch (error) {
        console.error('Error al enviar el correo de registro:', error);
        throw error;
    }
};
