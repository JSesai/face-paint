

export const isDevelopment = () => {
    const test = true;
    if (test) {
        return true
    } else {
        return false
    }
}