const responseHelper = (statusCode, data) => {
    return {
        statusCode,
        response: data
    };
};

export default responseHelper;
