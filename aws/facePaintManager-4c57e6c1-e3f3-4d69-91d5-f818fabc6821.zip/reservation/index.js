import { createAquote } from "./use-case-reservation.js"
import { isDevelopment } from "../utils/utils.js";

export const handlerReservation = async (event) => {
    const isDev = isDevelopment();
    const { httpMethod, path, body, pathParameters } = event

    let res;

    isDev && console.log('path->', path);

    switch (path) {
        case ('/reservation'):
            if (httpMethod === 'POST') res = await createAquote(body);
            return res
            break;

        default:
            throw new Error('No se encuentra el path del end point invocado')
    }
}