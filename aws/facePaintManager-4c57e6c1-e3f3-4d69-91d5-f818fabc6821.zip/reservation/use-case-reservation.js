import { insertObjectDynamo, getObjectDynamo } from "../dynamoDBService/dynamoService.js"
import { randomUUID } from 'crypto';
import { sendEmailReservation, sendEmailAquote } from "../emailService/emailService.js";


//Identificador de proyecto 
const identifier = process.env.IDENTIFIER
identifier ?? console.error('no hay identificador de proyecto');

//crear cotizacion
export const createAquote = async (body) => {
    console.log('creando cotizacion...');
    try {
        let reservacion = JSON.parse(body)
        const id = randomUUID();
        //guardar registro
        await insertObjectDynamo(`reservation-facePaint-${identifier}`, { ...reservacion, id });
        //enviar correo a majo
        await sendEmailAquote({ ...reservacion, id });
        return { statuscode: 200, message: 'En breve te contactaremos para brindarte tu cotización.' }

    } catch (error) {
        return { statuscode: 400, message: error.message };
    }
};

//crear reservacion
export const createReservation = async (reservacion) => {
   
    try {
        //guardar registro
        await insertObjectDynamo(`reservation-facePaint-${identifier}`, reservacion);
        //enviar correo a majo si el estatus del pago es aprovado
        if (reservacion.statusPayment == 'approved') { 
            await sendEmailReservation(reservacion);
        }
               
    } catch (error) {
        return { statuscode: 400, message: error.message };
    }
};