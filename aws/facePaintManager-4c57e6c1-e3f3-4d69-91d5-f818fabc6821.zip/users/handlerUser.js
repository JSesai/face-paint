import {
    handleCreateUser, handleAuthUser,
    handleConfirmUser, handleRecoverPassword,
    newPassword, handleCheckAuth
} from "./userController.js";
import { isDevelopment } from "../utils/utils.js";


export const handlerUser = async (event) => {
    const { httpMethod, path, body, pathParameters } = event
    const token = pathParameters ? pathParameters.id : ''
    let res;
    const isDev = isDevelopment();
    // isDev && console.log({ httpMethod, path, body, pathParameters });


    switch (path) {
        case ('/users'):
            if (httpMethod === 'POST') res = await handleCreateUser(body)
            return res
            break

        // case (`/users/confirm-account/${token}`):
        //     if (httpMethod === 'GET') res = await handleConfirmUser({ body, token })
        //     return res
        //     break

        case ('/users/login'):
            if (httpMethod === 'POST') res = await handleAuthUser(body)
            return res
            break

        case ('/users/forgot-password'):
            isDev && console.log('recuperando la contraseña');
            if (httpMethod === 'POST') res = await handleRecoverPassword(body)
            if (httpMethod === 'GET') res = await handleCheckAuth(event)
            if (httpMethod === 'PATCH') res = await newPassword(body)
          
            return res
            break

        // case (`/users/forgot-password/${token}`):
        //     console.log('recuperando la contraseña con el token');
        //     // if (httpMethod === 'GET') res = await handleCheckAuth(body)
        //     // if (httpMethod === 'POST') res = await newPassword(body)
        //     res = {statusCode: 200, body: 'ok'}
        //     return res 
        //     break

        case ('/users/profile'):
            if (httpMethod === 'GET') {
                res = await handleCheckAuth(event);
                return res;
            }
            break

        default:
            res = { statusCode: 200, message: 'No se encuentra el path del end point invocado' }

    }
}