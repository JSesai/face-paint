import { getObjectDynamo, getObjectById, insertObjectDynamo, updateObject } from '../dynamoDBService/dynamoService.js';
import { sendEmailRegister, sendEmailRecoverPassword } from '../emailService/emailService.js';
import { generateToken, verifyToken } from './generateJWT.js';
import CryptoJS from 'crypto-js';
import { randomUUID, randomBytes } from 'crypto';
import AppError from '../appError/AppError.js';
import errorHandler from '../appError/errorHandler.js';
import { isDevelopment } from "../utils/utils.js";
import responseHelper from "../utils/responseHelper.js";


//Identificador de proyecto 
const identifier = process.env.IDENTIFIER
identifier ?? console.error('no hay identificador de proyecto');
const isDev = isDevelopment();


export const handleCreateUser = async (itemUser) => {
    try {
        if (!itemUser) throw new AppError('No se ha proporcionado informacion para crear usuario', 400);
        let user = JSON.parse(itemUser);
        const listUsers = await getObjectDynamo(`users-facePaint-${identifier}`, 'email', user.email);
        if (listUsers.Count > 0) throw new AppError(`usuario ${user.email}  ya existe, desbes iniciar sesión o recupera tu cuenta`, 400);
        user.token = randomUUID();
        const salt = randomBytes(10).toString('hex');
        user.password = CryptoJS.SHA256(user.password + salt).toString(CryptoJS.enc.Hex);
        const saveUser = await insertObjectDynamo(`users-facePaint-${identifier}`, { ...user, salt, id: user.token });
        isDev && console.log(saveUser);
        if (!saveUser) throw new AppError(`usuario ${user.email}  no se creo`, 400)
        isDev && console.log('create user', saveUser);
        const message = 'Usuario Creado Correctamente, un administrador aprobara tu cuenta para ingresar';
        return responseHelper(200, { message });
    } catch (error) {
        return errorHandler(error);
    }
}

export const handleAuthUser = async (body) => {

    try {
        const { email, password } = JSON.parse(body);
        isDev && console.log('email', email);
        //validar que venga el email
        if (!email || !password) throw new AppError('No se han proporcionado datos completos', 400);
        const userExist = await getObjectDynamo(`users-facePaint-${identifier}`, 'email', email);
        if (userExist.Items.length === 0) throw new AppError(`No existe una cuenta con  ${email} Registrate!!`, 400);
        if (userExist.Items.length > 1) throw new AppError(`Existe duplicado de la cuenta con  ${email} contacta a soporte!!`, 400);
        const [userFind] = userExist.Items;
        if (!userFind.confirm) throw new AppError(`Usuario no confirmado, tu cuenta debe ser autorizada por el administrador`, 400);
        isDev && console.log('datos enviados', { email, password });  //compara password enviada VS password almacenada
        const passwordReceived = CryptoJS.SHA256(password + userFind.salt).toString(CryptoJS.enc.Hex);
        if (userFind.password != passwordReceived) throw new AppError(`Contraseña incorrecta`, 400);

        const user = { id: userFind.id, nombre: userFind.nombre, email: userFind.email, token: generateToken(userFind.id) };
        return responseHelper(200, user);

    } catch (error) {
        return errorHandler(error);
    }
}

export const handleConfirmUser = async ({ token }) => {
    try {
        const id = token
        await updateObject('users', id, { token: '', confirm: true });
        return responseHelper(200, { message: 'Usuario confirmado' });

    } catch (error) {
        return errorHandler(error);
    }
}

export const handleRecoverPassword = async (body) => {
    try {
        const { email } = JSON.parse(body);
        if (!email) throw new AppError('No se ha proporcionado email', 400);
        const userExist = await getObjectDynamo(`users-facePaint-${identifier}`, 'email', email);
        if (userExist.Count === 0) throw new AppError(`No existe una cuenta con  ${email}`, 400);
        const [userFind] = userExist.Items;
        if (!userFind.confirm) throw new AppError('Usuario no confirmado, tu cuenta debe ser autorizada por el administrador', 400);
        const token = generateToken(userFind.id);
        await sendEmailRecoverPassword({ email, nombre: userFind.nombre, token })
        const message = 'te hemos enviado un correo con las intrucciones';
        return responseHelper(200, { message });

    } catch (error) {
        return errorHandler(error);
    }

}

export const newPassword = async (body) => {

    try {
        let { password, id } = JSON.parse(body);
        if (!password || !id) throw new AppError('No se han proporcionado datos completos', 400);
        const salt = randomBytes(10).toString('hex');
        password = CryptoJS.SHA256(password + salt).toString(CryptoJS.enc.Hex);
        await updateObject(`users-facePaint-${identifier}`, id, { password, salt });
        return responseHelper(200, { message: 'Contraseña actualizada, ya puedes ingresar con tu nueva contraseña' });
    } catch (error) {
        return errorHandler(error);
    }
}

export const handleCheckAuth = async ({ headers }) => {

    if (!headers.Authorization) throw new AppError('No se ha proporcionado token', 400);
    if (headers.Authorization.startsWith('Bearer')) {
        try {
            //separamos por " " y tomamos la poscicion 1 que es donde esta el token
            const tokenReceived = headers.Authorization.split(" ")[1];
            //Decifra jwt
            const { id } = verifyToken(tokenReceived);
            //busamos el usuario por su id decodificado
            const { password, salt, token, confirm, dateRegister, ...user } = await getObjectById(`users-facePaint-${identifier}`, id);
            if (!dateRegister) throw new AppError('usuario no encontrado, registrate', 404);
            if (!confirm) throw new AppError('usuario no autorizado, contacta al administrador', 404);
            return responseHelper(200, user);

        } catch (error) {
            return errorHandler(error);

        }
    }

};

