

export class CustomError extends Error {
    constructor(message, statusCode) {
        super(message);
        this.statusCode = statusCode;
        this.name = 'CustomError';
        Error.captureStackTrace(this, this.constructor);
    }
}


export class AppError extends CustomError {
    constructor(message, statusCode = 1010) {
        super(message, statusCode);
        this.statusCode = statusCode;
        this.name = 'AppError';
    }
}

