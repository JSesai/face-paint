import { CustomError } from './customError.js'

const validateTypeError = (error) => {
    const isErrorCusmized = error instanceof CustomError;
    return isErrorCusmized
}

export default validateTypeError;