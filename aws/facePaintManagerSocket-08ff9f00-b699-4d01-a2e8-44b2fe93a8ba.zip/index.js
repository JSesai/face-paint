import { handlerConnectionEvent } from "./handlers/handlerConnectionEvent.js";
import { handlerEventTriger } from "./handlers/handlerEventTriger.js";
import isDevelopment from "./utils/isDevelopment.js";
import { AppError } from "./customError/customError.js";


export const handler = async (eventSocket) => {
 
  const identifier = process.env.IDENTIFIER  //Identificador de proyecto 
  if (!identifier) throw new AppError('no hay identificador de proyecto');
  eventSocket.projectIdentifier = identifier;


  const { eventSourceARN } = eventSocket;
  const res = await (eventSourceARN) ? handlerEventTriger(eventSocket) : handlerConnectionEvent(eventSocket);
  return res;

}




