import validateTypeError from "../customError/validateTypeError.js"
import { AppError } from "../customError/customError.js";
import responseHelper from "../utils/responseHelper.js";
import onConnect from "./onConnect.js";
import onDisconnect from "./onDisconnect.js";
import onMessageSocket from "./onMessageSocket.js";

export const handlerConnectionEvent = async (eventSocket) => {
console.log(eventSocket);
  const { requestContext } = eventSocket;
  const { eventType = '' } = requestContext;
  let res = null;
  
  try {
    switch (eventType.toUpperCase()) {

      case ('CONNECT'):
        res = await onConnect(eventSocket)
        break;

      case ('MESSAGE'):
        res = await onMessageSocket(eventSocket)
        break;

      case ('DISCONNECT'):
        res = await onDisconnect(eventSocket)
        break;

      default:
        throw new AppError('Evento desconocido - metodo no encontrado en handlerConnectionEvent :(');
        break
    }

    return res;
   
  } catch (error) {

    const isErrorCusmized = validateTypeError(error);
    if (!isErrorCusmized) console.log('Excepcion no controlada 🦜🦜 🍻', error);

    return {
      statusCode: isErrorCusmized ? error.statusCode : 500,
      error: true,
      body: JSON.stringify(isErrorCusmized ? { message: error.message } : { message: 'Error en servidor' })
    }

  }

}
