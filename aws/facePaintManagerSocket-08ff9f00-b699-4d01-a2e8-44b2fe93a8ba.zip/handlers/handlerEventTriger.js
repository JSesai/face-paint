import responseHelper from "../utils/responseHelper.js";



export const handlerEventTriger = async (eventTriger) => {
    console.log('handlerTrigers');
    const { eventSourceARN } = eventTriger;
    //Identificador de proyecto 
    // const identifier = process.env.IDENTIFIER
    identifier ?? console.error('no hay identificador de proyecto');
  
    const message = 'conexion exitosa';
    return responseHelper(200, { message });
  
  }
  