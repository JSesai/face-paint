import responseHelper from "../utils/responseHelper.js";


const onMessageSocket = (eventSocket) => {

    const message = 'mensaje recibido exitosamente';
    return responseHelper(200, { message });
}

export default onMessageSocket;