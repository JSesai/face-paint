import responseHelper from "../utils/responseHelper.js";


const onDisconnect = (eventoDisconnect) => {
    console.log('evento de desconectar', eventoDisconnect)

    //eliminar el id de conexion en la tabla WebSocketConnections
    // Estructura de la tabla (WebSocketConnections)

    // PK (projectId#connectionId)	projectId	connectionId	userId	createdAt
    // projectA#abc123	projectA	abc123	user1	2025-03-08
    // projectB#xyz456	projectB	xyz456	user2	2025-03-08

    // const connectionId = requestContext.connectionId;
  // const routeKey = requestContext.routeKey;
    const message = 'deconexiòn establecida correctamente';
    return responseHelper(200, { message });

}

export default onDisconnect;
