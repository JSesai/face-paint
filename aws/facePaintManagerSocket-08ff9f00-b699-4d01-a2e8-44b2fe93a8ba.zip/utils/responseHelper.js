const responseHelper = (statusCode, data) => {

    return {
        headers: {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Credentials": true,
        },
        statusCode,
        body: JSON.stringify(data)

    };
};

export default responseHelper;
