const isDev = true;

const isDevelopment = () => isDev

export default isDevelopment;